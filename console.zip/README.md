# console

Console processing system designed to keep out bad eggs. This system will loop through a list of banned words and cross-check the servers for that word.

It also looks at the file tree and sends suspicious folders to the approval team, once approved, servers will be promptly removed.
